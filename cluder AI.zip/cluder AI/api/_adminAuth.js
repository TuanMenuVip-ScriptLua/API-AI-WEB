import crypto from "crypto";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const TOKEN_SECRET =
  process.env.ADMIN_TOKEN_SECRET || ADMIN_PASSWORD || "fallback";

const TOKEN_TTL_MS = 1000 * 60 * 60 * 8; // 8 giờ

export function getAdminPassword() {
  return ADMIN_PASSWORD;
}

export function signAdminToken(payload = {}) {
  const data = Buffer.from(
    JSON.stringify({ ...payload, exp: Date.now() + TOKEN_TTL_MS })
  ).toString("base64url");
  const sig = crypto
    .createHmac("sha256", TOKEN_SECRET + "::admin")
    .update(data)
    .digest("base64url");
  return `${data}.${sig}`;
}

export function verifyAdminToken(token) {
  if (!token || typeof token !== "string") return null;
  const [data, sig] = token.split(".");
  if (!data || !sig) return null;
  const expected = crypto
    .createHmac("sha256", TOKEN_SECRET + "::admin")
    .update(data)
    .digest("base64url");
  if (expected !== sig) return null;
  try {
    const payload = JSON.parse(Buffer.from(data, "base64url").toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Đọc token từ header Authorization: Bearer xxx */
export function readToken(req) {
  const auth = req.headers.authorization || "";
  return auth.replace(/^Bearer\s+/i, "");
}

/** Middleware cho endpoint cần admin token */
export function requireAdmin(req, res) {
  const payload = verifyAdminToken(readToken(req));
  if (!payload) {
    res.status(401).json({ success: false, error: "Unauthorized" });
    return null;
  }
  return payload;
}