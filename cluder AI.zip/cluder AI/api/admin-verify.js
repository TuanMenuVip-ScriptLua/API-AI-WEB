import { requireAdmin } from "./_adminAuth.js";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  const payload = requireAdmin(req, res);
  if (!payload) return;

  return res.status(200).json({
    success: true,
    user: payload.user,
    exp: payload.exp,
    expiresIn: Math.floor((payload.exp - Date.now()) / 1000),
  });
}