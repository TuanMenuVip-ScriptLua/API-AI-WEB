import { requireAdmin } from "./_adminAuth.js";
import { getMaintenance, setMaintenance } from "./_maintenance.js";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") return res.status(204).end();

  // GET — public, ai cũng đọc được để biết có đang bảo trì không
  if (req.method === "GET") {
    return res.status(200).json({ success: true, ...getMaintenance() });
  }

  // POST — chỉ admin mới được đổi trạng thái
  if (req.method === "POST") {
    const payload = requireAdmin(req, res);
    if (!payload) return;

    try {
      const { enabled, message } = req.body || {};
      const state = setMaintenance(enabled, message);
      return res.status(200).json({ success: true, ...state });
    } catch (err) {
      return res.status(500).json({ success: false, error: err?.message });
    }
  }

  return res.status(405).json({ success: false, error: "Method not allowed" });
}