import { GoogleGenAI } from "@google/genai";

const GEMINI_API_KEY = "AQ.Ab8RN6IY1SzyATHlxBoXYInwnSUSIb42t95a74zIQaro0-qmTQ";
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  try {
    const { input, model = "gemini-3.8-flash" } = req.body || {};
    if (!input || typeof input !== "string") {
      return res.status(400).json({ success: false, error: "Missing 'input' string in body" });
    }
    const response = await ai.models.generateContent({
      model,
      contents: input,
    });
    const output = response.text || "";
    return res.status(200).json({ success: true, model, output });
  } catch (err) {
    console.error("Gemini error:", err);
    return res.status(500).json({ success: false, error: err?.message || "Internal server error" });
  }
}