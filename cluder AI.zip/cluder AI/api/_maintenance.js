// State trong memory — reset khi cold start
let maintenanceMode = false;
let maintenanceMessage = "Hệ thống đang bảo trì. Vui lòng quay lại sau.";

export function getMaintenance() {
  return { enabled: maintenanceMode, message: maintenanceMessage };
}

export function setMaintenance(enabled, message) {
  maintenanceMode = !!enabled;
  if (typeof message === "string" && message.trim()) {
    maintenanceMessage = message.trim();
  }
  return getMaintenance();
}