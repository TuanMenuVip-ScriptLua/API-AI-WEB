import OpenAI from "openai";
import { requireToken } from "./_auth.js";
import { getMaintenance } from "./_maintenance.js";

const GROQ_API_KEY = "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";

const client = new OpenAI({
  apiKey: GROQ_API_KEY,
  baseURL: "https://api.groq.com/openai/v1",
});

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  // Chặn khi bảo trì
  const m = getMaintenance();
  if (m.enabled) {
    return res.status(503).json({ success: false, error: m.message });
  }

  // Yêu cầu token hợp lệ
  if (!requireToken(req, res)) return;

  try {
    const { input, model = "qwen/qwen3.6-27b" } = req.body || {};
    if (!input || typeof input !== "string") {
      return res.status(400).json({ success: false, error: "Missing 'input' string in body" });
    }

    let output = "";
    try {
      const r = await client.responses.create({ input, model });
      output = r.output_text || "";
    } catch {
      const r = await client.chat.completions.create({
        model,
        messages: [{ role: "user", content: input }],
      });
      output = r.choices?.[0]?.message?.content || "";
    }

    return res.status(200).json({ success: true, model, output });
  } catch (err) {
    console.error("Groq error:", err);
    return res.status(500).json({ success: false, error: err?.message || "Internal server error" });
  }
}