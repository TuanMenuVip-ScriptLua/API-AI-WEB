const GROQ_API_KEY = "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";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const {
      input,
      model = "meta-llama/llama-prompt-guard-2-86m",
    } = req.body || {};
    if (!input) return res.status(400).json({ error: "Missing 'input'" });

    const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: input }],
        max_tokens: 20,
      }),
    });

    const data = await r.json();
    if (!r.ok) {
      return res.status(r.status).json({
        success: false,
        error: data.error?.message || JSON.stringify(data),
      });
    }

    const raw = data.choices?.[0]?.message?.content || "";
    return res.status(200).json({ success: true, raw });
  } catch (err) {
    console.error("Guard error:", err);
    return res.status(500).json({ success: false, error: err?.message });
  }
}