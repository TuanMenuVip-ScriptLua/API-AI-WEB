import crypto from "crypto";
import { getAdminPassword, signAdminToken } from "./_adminAuth.js";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  const ADMIN_PASSWORD = getAdminPassword();
  if (!ADMIN_PASSWORD) {
    return res.status(500).json({
      success: false,
      error: "Server misconfigured: missing ADMIN_PASSWORD",
    });
  }

  try {
    const { password } = req.body || {};
    if (!password || typeof password !== "string") {
      return res.status(400).json({ success: false, error: "Missing password" });
    }

    const a = Buffer.from(password);
    const b = Buffer.from(ADMIN_PASSWORD);
    const ok = a.length === b.length && crypto.timingSafeEqual(a, b);

    if (!ok) {
      await new Promise(r => setTimeout(r, 600));
      return res.status(401).json({ success: false, error: "Sai mật khẩu" });
    }

    const token = signAdminToken({ user: "admin" });
    return res.status(200).json({ success: true, token });
  } catch (err) {
    console.error("admin-login error:", err);
    return res.status(500).json({ success: false, error: err?.message });
  }
}