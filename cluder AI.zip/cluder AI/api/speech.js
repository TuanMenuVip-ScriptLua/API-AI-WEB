const GROQ_API_KEY = "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";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const {
      input,
      model = "canopylabs/orpheus-v1-english",
      voice = "autumn",
    } = req.body || {};
    if (!input) return res.status(400).json({ error: "Missing 'input'" });

    const r = await fetch("https://api.groq.com/openai/v1/audio/speech", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        input,
        voice,
        response_format: "wav",   // ← ĐỔI TỪ "mp3" SANG "wav"
      }),
    });

    if (!r.ok) {
      const t = await r.text();
      return res.status(r.status).json({ success: false, error: t });
    }

    const buf = Buffer.from(await r.arrayBuffer());
    res.setHeader("Content-Type", "audio/wav");               // ← đổi luôn
    res.setHeader("Content-Disposition", 'inline; filename="speech.wav"');
    return res.status(200).send(buf);
  } catch (err) {
    console.error("TTS error:", err);
    return res.status(500).json({ success: false, error: err?.message });
  }
}