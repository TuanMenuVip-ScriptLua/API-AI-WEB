import OpenAI from "openai";

const MOONSHOT_API_KEY = "sk-uwFIlcNbmPwfIyRY93gF30fTUD7PWvR6TBILdyk5jR2LlhEU";

const kimi = new OpenAI({
  apiKey: MOONSHOT_API_KEY,
  baseURL: "https://api.moonshot.ai/v1",
});

const SYSTEM_PROMPT =
  "You are Kimi, an AI assistant provided by Moonshot AI. " +
  "You are especially good at conversations in Chinese and English. " +
  "You provide users with safe, helpful, and accurate answers. " +
  "You also refuse to answer any questions involving terrorism, racism, " +
  "pornography, violence, or similar harmful content. " +
  "Moonshot AI is a proper noun and must not be translated into other languages.";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { input, model = "kimi-k3" } = req.body || {};
    if (!input || typeof input !== "string") {
      return res.status(400).json({ error: "Missing 'input' string in body" });
    }

    const r = await kimi.chat.completions.create({
      model,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: input },
      ],
    });

    const output = r.choices?.[0]?.message?.content || "";
    return res.status(200).json({ success: true, model, output });
  } catch (err) {
    console.error("Kimi error:", err);
    return res.status(500).json({
      success: false,
      error: err?.message || "Internal server error",
    });
  }
}