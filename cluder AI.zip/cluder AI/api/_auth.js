import crypto from "crypto";

const SECRET = process.env.ADMIN_TOKEN_SECRET || process.env.ADMIN_PASSWORD || "fallback-secret-change-me";
const TOKEN_TTL_MS = 1000 * 60 * 60 * 2;

export function signToken(payload = {}) {
  const data = Buffer.from(
    JSON.stringify({ ...payload, exp: Date.now() + TOKEN_TTL_MS })
  ).toString("base64url");
  const sig = crypto.createHmac("sha256", SECRET + "::api-token").update(data).digest("base64url");
  return `${data}.${sig}`;
}

export function verifyToken(token) {
  if (!token || typeof token !== "string") return null;
  const [data, sig] = token.split(".");
  if (!data || !sig) return null;
  const expected = crypto.createHmac("sha256", SECRET + "::api-token").update(data).digest("base64url");
  if (expected !== sig) return null;
  try {
    const payload = JSON.parse(Buffer.from(data, "base64url").toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function requireToken(req, res) {
  const auth = req.headers.authorization || "";
  const token = auth.replace(/^Bearer\s+/i, "");
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ success: false, error: "Missing or invalid token" });
    return false;
  }
  return true;
}