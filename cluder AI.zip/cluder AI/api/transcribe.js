import OpenAI from "openai";

const GROQ_API_KEY = "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";
const client = new OpenAI({ apiKey: GROQ_API_KEY, baseURL: "https://api.groq.com/openai/v1" });

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const body = Buffer.concat(chunks);

    const ctype = req.headers["content-type"] || "";
    const m = ctype.match(/boundary=(.+)$/);
    if (!m) return res.status(400).json({ error: "Missing multipart boundary" });
    const boundary = "--" + m[1];

    const parts = [];
    let start = body.indexOf(boundary) + boundary.length + 2;
    while (true) {
      const end = body.indexOf(boundary, start);
      if (end === -1) break;
      parts.push(body.slice(start, end - 2));
      start = end + boundary.length + 2;
    }

    let fileBuf, filename, contentType, model = "whisper-large-v3-turbo", language;

    for (const part of parts) {
      const sep = part.indexOf("\r\n\r\n");
      if (sep === -1) continue;
      const headers = part.slice(0, sep).toString();
      const content = part.slice(sep + 4);

      const nameMatch = headers.match(/name="([^"]+)"/);
      const fnameMatch = headers.match(/filename="([^"]+)"/);
      const typeMatch = headers.match(/Content-Type:\s*(.+)/i);
      if (!nameMatch) continue;
      const name = nameMatch[1];

      if (fnameMatch) {
        fileBuf = content;
        filename = fnameMatch[1];
        contentType = typeMatch ? typeMatch[1].trim() : "application/octet-stream";
      } else {
        const val = content.toString().trim();
        if (name === "model") model = val;
        if (name === "language") language = val;
      }
    }

    if (!fileBuf) return res.status(400).json({ error: "Missing file" });

    const file = new File([fileBuf], filename, { type: contentType });
    const params = { file, model };
    if (language) params.language = language;

    const r = await client.audio.transcriptions.create(params);
    return res.status(200).json({ success: true, text: r.text });
  } catch (err) {
    console.error("STT error:", err);
    return res.status(500).json({ success: false, error: err?.message || "Internal error" });
  }
}